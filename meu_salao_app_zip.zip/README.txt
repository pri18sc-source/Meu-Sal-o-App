
Meu Salão App - Projeto Flutter (offline)
Arquivos principais: lib/, pubspec.yaml

Como usar:
1. Abra no VSCode ou Android Studio.
2. Execute `flutter pub get`.
3. Rode no dispositivo com `flutter run`.
4. Tela de login cria conta localmente (email+senha).
5. Vá em Clientes para cadastrar clientes.
6. Agende serviços em 'Agendar Serviço'.
7. Veja agenda, relatórios e notificações (agendadas 30min antes).

Observações:
- Substitua assets/icons/icon.png por seu logotipo (192x192) para ícone.
- Para gerar APK: `flutter build apk --release`.
