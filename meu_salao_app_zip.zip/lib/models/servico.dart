
class Servico {
  int? id;
  String cliente;
  String tipo;
  DateTime dataHora;
  int duracaoMin; // tempo estimado em minutos
  double valor;

  Servico({this.id, required this.cliente, required this.tipo, required this.dataHora, required this.duracaoMin, required this.valor});

  Map<String, dynamic> toMap() => {
    'id': id,
    'cliente': cliente,
    'tipo': tipo,
    'dataHora': dataHora.toIso8601String(),
    'duracaoMin': duracaoMin,
    'valor': valor,
  };

  factory Servico.fromMap(Map<String, dynamic> m) => Servico(
    id: m['id'] as int?,
    cliente: m['cliente'] as String,
    tipo: m['tipo'] as String,
    dataHora: DateTime.parse(m['dataHora'] as String),
    duracaoMin: m['duracaoMin'] as int,
    valor: (m['valor'] as num).toDouble(),
  );
}
