
class UserApp {
  int? id;
  String email;
  String password;

  UserApp({this.id, required this.email, required this.password});

  Map<String, dynamic> toMap() => {
    'id': id,
    'email': email,
    'password': password,
  };

  factory UserApp.fromMap(Map<String, dynamic> m) => UserApp(
    id: m['id'] as int?,
    email: m['email'] as String,
    password: m['password'] as String,
  );
}
