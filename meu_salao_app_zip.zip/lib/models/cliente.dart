
class Cliente {
  int? id;
  String nome;
  String telefone;
  String email;

  Cliente({this.id, required this.nome, required this.telefone, required this.email});

  Map<String, dynamic> toMap() => {
    'id': id,
    'nome': nome,
    'telefone': telefone,
    'email': email,
  };

  factory Cliente.fromMap(Map<String, dynamic> m) => Cliente(
    id: m['id'] as int?,
    nome: m['nome'] as String,
    telefone: m['telefone'] as String,
    email: m['email'] as String,
  );
}
