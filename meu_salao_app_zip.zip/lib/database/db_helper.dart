
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/cliente.dart';
import '../models/servico.dart';
import '../models/user.dart';

class DBHelper {
  static Database? _db;

  static Future<Database> getDB() async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'meu_salao.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, password TEXT)
      ''');
      await db.execute('''
        CREATE TABLE clientes(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, telefone TEXT, email TEXT)
      ''');
      await db.execute('''
        CREATE TABLE servicos(id INTEGER PRIMARY KEY AUTOINCREMENT, cliente TEXT, tipo TEXT, dataHora TEXT, duracaoMin INTEGER, valor REAL)
      ''');
    });
    return _db!;
  }

  // User
  static Future<int> inserirUser(UserApp u) async {
    final db = await getDB();
    return await db.insert('users', u.toMap());
  }

  static Future<UserApp?> pegarUserPorEmail(String email) async {
    final db = await getDB();
    final res = await db.query('users', where: 'email = ?', whereArgs: [email]);
    if (res.isEmpty) return null;
    return UserApp.fromMap(res.first);
  }

  // Clientes
  static Future<int> inserirCliente(Cliente c) async {
    final db = await getDB();
    return await db.insert('clientes', c.toMap());
  }

  static Future<List<Cliente>> pegarClientes() async {
    final db = await getDB();
    final data = await db.query('clientes', orderBy: 'nome');
    return data.map((e) => Cliente.fromMap(e)).toList();
  }

  // Servicos
  static Future<int> inserirServico(Servico s) async {
    final db = await getDB();
    return await db.insert('servicos', s.toMap());
  }

  static Future<List<Servico>> pegarServicos() async {
    final db = await getDB();
    final data = await db.query('servicos', orderBy: 'dataHora');
    return data.map((e) => Servico.fromMap(e)).toList();
  }

  static Future<List<Servico>> pegarServicosNoPeriodo(DateTime inicio, DateTime fim) async {
    final db = await getDB();
    final data = await db.rawQuery('SELECT * FROM servicos WHERE dataHora >= ? AND dataHora <= ? ORDER BY dataHora', [inicio.toIso8601String(), fim.toIso8601String()]);
    return data.map((e) => Servico.fromMap(e)).toList();
  }
}
