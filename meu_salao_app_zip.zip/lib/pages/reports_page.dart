
import 'package:flutter/material.dart';
import '../database/db_helper.dart';
import '../models/servico.dart';
import 'package:intl/intl.dart';

class ReportsPage extends StatefulWidget {
  @override
  _ReportsPageState createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  List<Servico> servicos = [];

  @override
  void initState() {
    super.initState();
    carregar();
  }

  void carregar() async {
    final s = await DBHelper.pegarServicos();
    setState((){ servicos = s; });
  }

  double ganhosNoPeriodo(DateTime inicio, DateTime fim) {
    final filt = servicos.where((s) => s.dataHora.isAfter(inicio.subtract(Duration(seconds:1))) && s.dataHora.isBefore(fim.add(Duration(seconds:1))));
    return filt.fold(0.0, (sum, s) => sum + s.valor);
  }

  Map<String,int> servicosMais() {
    final map = <String,int>{};
    for (var s in servicos) {
      map[s.tipo] = (map[s.tipo] ?? 0) + 1;
    }
    return map;
  }

  @override
  Widget build(BuildContext context) {
    final hoje = DateTime.now();
    final inicioDia = DateTime(hoje.year, hoje.month, hoje.day);
    final fimDia = inicioDia.add(Duration(days:1)).subtract(Duration(seconds:1));
    final inicioSemana = inicioDia.subtract(Duration(days: hoje.weekday - 1));
    final fimSemana = inicioSemana.add(Duration(days:7)).subtract(Duration(seconds:1));
    final inicioMes = DateTime(hoje.year, hoje.month, 1);
    final fimMes = DateTime(hoje.year, hoje.month + 1, 1).subtract(Duration(seconds:1));

    final ganhosDia = ganhosNoPeriodo(inicioDia, fimDia);
    final ganhosSemana = ganhosNoPeriodo(inicioSemana, fimSemana);
    final ganhosMes = ganhosNoPeriodo(inicioMes, fimMes);
    final topServ = servicosMais();

    return Scaffold(
      appBar: AppBar(title: Text('Relatórios')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Ganhos', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height:8),
            Text('Hoje: R\$ \${ganhosDia.toStringAsFixed(2)}'),
            Text('Esta semana: R\$ \${ganhosSemana.toStringAsFixed(2)}'),
            Text('Este mês: R\$ \${ganhosMes.toStringAsFixed(2)}'),
            Divider(),
            Text('Serviços mais realizados', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ...topServ.entries.map((e) => Text('\${e.key}: \${e.value} vezes')).toList(),
          ],
        ),
      ),
    );
  }
}
