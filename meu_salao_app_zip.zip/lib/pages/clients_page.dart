
import 'package:flutter/material.dart';
import '../database/db_helper.dart';
import '../models/cliente.dart';

class ClientsPage extends StatefulWidget {
  @override
  _ClientsPageState createState() => _ClientsPageState();
}

class _ClientsPageState extends State<ClientsPage> {
  final nomeCtrl = TextEditingController();
  final telCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  List<Cliente> clientes = [];

  @override
  void initState() {
    super.initState();
    carregar();
  }

  void carregar() async {
    final c = await DBHelper.pegarClientes();
    setState(() { clientes = c; });
  }

  void salvar() async {
    if (nomeCtrl.text.isEmpty) return;
    final c = Cliente(nome: nomeCtrl.text, telefone: telCtrl.text, email: emailCtrl.text);
    await DBHelper.inserirCliente(c);
    nomeCtrl.clear(); telCtrl.clear(); emailCtrl.clear();
    carregar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Clientes')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(controller: nomeCtrl, decoration: InputDecoration(labelText: 'Nome')),
            TextField(controller: telCtrl, decoration: InputDecoration(labelText: 'Telefone')),
            TextField(controller: emailCtrl, decoration: InputDecoration(labelText: 'Email')),
            SizedBox(height: 8),
            ElevatedButton(onPressed: salvar, child: Text('Salvar Cliente')),
            Divider(),
            Expanded(child: ListView.builder(
              itemCount: clientes.length,
              itemBuilder: (_, i) {
                final c = clientes[i];
                return ListTile(
                  title: Text(c.nome),
                  subtitle: Text('${c.telefone} | ${c.email}'),
                );
              },
            ))
          ],
        ),
      ),
    );
  }
}
