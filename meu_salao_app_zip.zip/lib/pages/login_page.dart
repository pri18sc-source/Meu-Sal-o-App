
import 'package:flutter/material.dart';
import '../database/db_helper.dart';
import '../models/user.dart';
import 'home_page.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  void _login() async {
    final user = await DBHelper.pegarUserPorEmail(emailCtrl.text.trim());
    if (user == null) {
      // register quick
      final u = UserApp(email: emailCtrl.text.trim(), password: passCtrl.text);
      await DBHelper.inserirUser(u);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Conta criada e conectada')));
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomePage()));
    } else {
      if (user.password == passCtrl.text) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomePage()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Senha incorreta')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Meu Salão App', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            TextField(controller: emailCtrl, decoration: InputDecoration(labelText: 'Email')),
            TextField(controller: passCtrl, decoration: InputDecoration(labelText: 'Senha'), obscureText: true),
            SizedBox(height: 12),
            ElevatedButton(onPressed: _login, child: Text('Entrar / Criar conta')),
          ],
        ),
      ),
    );
  }
}
