
import 'package:flutter/material.dart';
import 'clients_page.dart';
import 'schedule_page.dart';
import 'agenda_page.dart';
import 'reports_page.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Meu Salão App')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton.icon(
              icon: Icon(Icons.person_add),
              label: Text('Clientes'),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ClientsPage())),
            ),
            ElevatedButton.icon(
              icon: Icon(Icons.calendar_today),
              label: Text('Agendar Serviço'),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SchedulePage())),
            ),
            ElevatedButton.icon(
              icon: Icon(Icons.view_agenda),
              label: Text('Agenda'),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AgendaPage())),
            ),
            ElevatedButton.icon(
              icon: Icon(Icons.bar_chart),
              label: Text('Relatórios'),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReportsPage())),
            ),
          ],
        ),
      ),
    );
  }
}
