
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import '../database/db_helper.dart';
import '../models/servico.dart';

class AgendaPage extends StatefulWidget {
  @override
  _AgendaPageState createState() => _AgendaPageState();
}

class _AgendaPageState extends State<AgendaPage> {
  DateTime _focused = DateTime.now();
  DateTime _selected = DateTime.now();
  Map<DateTime, List<Servico>> eventos = {};

  @override
  void initState() {
    super.initState();
    carregar();
  }

  void carregar() async {
    final s = await DBHelper.pegarServicos();
    Map<DateTime, List<Servico>> map = {};
    for (var e in s) {
      final d = DateTime(e.dataHora.year, e.dataHora.month, e.dataHora.day);
      map.putIfAbsent(d, () => []).add(e);
    }
    setState(() { eventos = map; });
  }

  List<Servico> _getEventos(DateTime day) => eventos[DateTime(day.year, day.month, day.day)] ?? [];

  @override
  Widget build(BuildContext context) {
    final list = _getEventos(_selected);
    return Scaffold(
      appBar: AppBar(title: Text('Agenda')),
      body: Column(
        children: [
          TableCalendar(
            firstDay: DateTime.now().subtract(Duration(days:365)),
            lastDay: DateTime.now().add(Duration(days:365*5)),
            focusedDay: _focused,
            selectedDayPredicate: (d) => isSameDay(d, _selected),
            onDaySelected: (sel, foc){ setState(()=> _selected = sel; _focused = foc); },
            eventLoader: _getEventos,
          ),
          Expanded(child: ListView.builder(itemCount: list.length, itemBuilder: (_,i){
            final s = list[i];
            return ListTile(title: Text('\${s.cliente} - \${s.tipo}'), subtitle: Text('\${s.dataHora.hour.toString().padLeft(2,'0')}:\${s.dataHora.minute.toString().padLeft(2,'0')} | \${s.duracaoMin} min'), trailing: Text('R\$ \${s.valor.toStringAsFixed(2)}'));
          }))
        ],
      ),
    );
  }
}
