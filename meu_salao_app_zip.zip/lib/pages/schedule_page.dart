
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/db_helper.dart';
import '../models/servico.dart';
import '../notifications/notification_helper.dart';

class SchedulePage extends StatefulWidget {
  @override
  _SchedulePageState createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  final clienteCtrl = TextEditingController();
  final tipoCtrl = TextEditingController();
  final valorCtrl = TextEditingController();
  int duracao = 60; // minutes
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  void _pickDateTime() async {
    final d = await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime.now(), lastDate: DateTime(2100));
    if (d == null) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (t == null) return;
    setState(() {
      selectedDate = d;
      selectedTime = t;
    });
  }

  Future<bool> _checkConflict(DateTime start, int minutes) async {
    final servs = await DBHelper.pegarServicos();
    final end = start.add(Duration(minutes: minutes));
    for (var s in servs) {
      final sStart = s.dataHora;
      final sEnd = sStart.add(Duration(minutes: s.duracaoMin));
      if (start.isBefore(sEnd) && end.isAfter(sStart)) return true;
    }
    return false;
  }

  void _save() async {
    if (clienteCtrl.text.isEmpty || tipoCtrl.text.isEmpty || selectedDate == null || selectedTime == null) return;
    final dt = DateTime(selectedDate!.year, selectedDate!.month, selectedDate!.day, selectedTime!.hour, selectedTime!.minute);
    final conflict = await _checkConflict(dt, duracao);
    if (conflict) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Conflito de horário! Escolha outro horário.')));
      return;
    }
    final s = Servico(cliente: clienteCtrl.text, tipo: tipoCtrl.text, dataHora: dt, duracaoMin: duracao, valor: double.tryParse(valorCtrl.text) ?? 0.0);
    await DBHelper.inserirServico(s);
    // agendar notificação 30 minutos antes
    await NotificationHelper.scheduleNotification(dt.millisecondsSinceEpoch % 100000, 'Lembrete: ${s.tipo}', '${s.cliente} às ${DateFormat.Hm().format(dt)}', dt.subtract(Duration(minutes: 30)));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Agendado com sucesso')));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final display = selectedDate == null ? 'Selecione data e hora' : '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year} ${selectedTime?.format(context) ?? ''}';
    return Scaffold(
      appBar: AppBar(title: Text('Agendar Serviço')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(controller: clienteCtrl, decoration: InputDecoration(labelText: 'Nome do Cliente')),
            TextField(controller: tipoCtrl, decoration: InputDecoration(labelText: 'Tipo de Serviço (corte, coloração, manicure...)')),
            Row(children: [
              Expanded(child: TextField(controller: valorCtrl, decoration: InputDecoration(labelText: 'Valor (R\$)'))),
              SizedBox(width:8),
              DropdownButton<int>(value: duracao, items: [30,45,60,90,120].map((e) => DropdownMenuItem(value: e, child: Text('\${e} min'))).toList(), onChanged: (v){ setState(()=> duracao = v ?? 60); })
            ]),
            SizedBox(height:8),
            ElevatedButton(onPressed: _pickDateTime, child: Text(display)),
            SizedBox(height:8),
            ElevatedButton(onPressed: _save, child: Text('Salvar Agendamento')),
          ],
        ),
      ),
    );
  }
}
